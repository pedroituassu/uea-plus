let field = document.getElementById("senha");

field.setAttribute("type", "password")